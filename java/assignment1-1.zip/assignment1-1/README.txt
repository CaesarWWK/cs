Enter Commands to Continue !  : （Type Help for details)crete 2 1 Slow
Enter the name: 
weikuan
Enter the color: 
red
Print
     .     .     .     .     .     .     .     . 
weikuanredS     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
move 2 1 right
Move Complete
1 1
Print
     .     .     .     .     .     .     .     . 
     .weikuanredS     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
crete 4 4 Fast
Enter the name: 
weikuan
Enter the color: 
blue
move 4 4 right 2
weikuanMove Complete
Print
     .     .     .     .     .     .     .     . 
     .weikuanredS     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .weikuanblueF     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
crete 1 4 FastFlexible
Enter the name: 
weikuan
Enter the color: 
Black
move 1 4 up 2
weikuansddOut of Boundry


Enter Commands to Continue !  : （Type Help for details)crete 1 4 FastFlexible
Enter the name: 
asd
Enter the color: 
asd
move 1 4 down 2
asdsddMove Complete
Print
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .asdasdFF     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
move 3 4 up 2
asdsddMove Complete
Print
     .     .     .asdasdFF     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 
     .     .     .     .     .     .     .     . 

